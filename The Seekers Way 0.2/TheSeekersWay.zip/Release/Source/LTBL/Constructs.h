#ifndef LTBL_CONSTRUCTS_H
#define LTBL_CONSTRUCTS_H

#include <LTBL/Constructs/Vec2f.h>
#include <LTBL/Constructs/AABB.h>
#include <LTBL/Constructs/Point2i.h>
#include <LTBL/Constructs/Color3f.h>

#endif